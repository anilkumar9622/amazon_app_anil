import React from 'react'
import Subcomponent from '../dash/helper/subcomponent'

export default function firelite2() {
  return (
    <>
        <div>
                <img src="https://m.media-amazon.com/images/I/61KjlGbj8WS._SX679_.jpg"
                    style={{ height: '700px', width: '648px', alignItems: 'center', margin: '30px 30px' }} alt='img' />
            </div>
            <Subcomponent />

            <div>
                <img src="https://m.media-amazon.com/images/G/31/kindle/journeys/eyDtXktMqw2Bzc0EbZnPPUBfQY4I9fyaxFgbKnkCwjLU3D/NDBjNjVlZjYt"
                    style={{ height: '650px', width: '1148px', alignItems: 'center', margin: '30px 30px' }} alt='img' />
            </div>

            <div>
                <img src="https://m.media-amazon.com/images/G/31/kindle/journeys/eyDtXktMqw2Bzc0EbZnPPUBfQY4I9fyaxFgbKnkCwjLU3D/ZWE0NTJiMWEt"
                    style={{ height: '650px', width: '1448px', alignItems: 'center', margin: '30px 30px' }} alt='img' />
            </div>
    </>
  )
}
