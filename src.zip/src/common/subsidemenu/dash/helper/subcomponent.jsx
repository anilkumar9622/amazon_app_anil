import React from 'react'


export default function Subcomponent() {
  return (
    <>
      <div style={{ background: 'linear-gradient(#dfebf0, #f5f9fa)',background: 'linear-gradient(#e66465, #9198e5)', width: '100%', height: '50px', display: 'flex', margin: '60px 30px 50px 30px' }}>
                <div style={{ background: 'linear-gradient(#f2f6f7, white)', width: '100%', height: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '15px', paddingLeft: '0px', gap: '20px' }}>
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '1.1vw', color: '', paddingTop: '7px' }}>
                        <a href="" class="ex1" style={{ color: 'black' }} >
                            <h4>Jump to:</h4></a>

                    </div>
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '1.2vw', color: '' }}>
                        <a href="" class="ex1" style={{ color: 'black' }}>
                            Compare
                        </a>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '1.2vw', color: '' }}>
                        <a href="" class="ex1" style={{ color: 'black' }}>
                            Technical
                        </a>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '1.2vw', color: '' }}>
                        <a href="" class="ex1" style={{ color: 'black' }}>
                            details
                        </a>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '1.2vw', color: '' }}>
                        <a href="" class="ex1" style={{ color: 'black' }} >
                            Customer
                        </a>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '1.2vw', color: '' }}>
                        <a href="" class="ex1" style={{ color: 'black' }} >
                            questions & answers
                        </a>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '1.2vw', color: '' }}>
                        <a href="" class="ex1" style={{ color: 'black' }} >
                            Customer reviews
                        </a>
                    </div>
                </div></div>

    </>
  )
}
