
import React, { useEffect, useState } from 'react'
import PopOver from './popover'


export default function ModalView(props) {
   console.log(props);
   const [showModal, setshowModal] = useState(false)

   useEffect(() => {
      props.toggle != null && setshowModal(!showModal)
   }, [props.toggle])



   return (
      <>
         {showModal && (<PopOver showModal={showModal} setshowModal={setshowModal}>

          
         </PopOver >
         )
         }
      </>
   )
}
