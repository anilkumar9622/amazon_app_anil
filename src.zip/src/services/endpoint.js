export default  { 
    addToCart : "/addCart",
   
}

